# Continuidade atual — reconciliação dos dossiês, 22/10/2026

Branch `feat/ciclo-2026-2027-transicao`; commit-base `6478f93a50d03270a78959730221f2ea5a643658`. O diff local contém as rodadas 1–3 e a reconciliação; não houve commit, merge, publicação nem alteração no relatório 2025–2026. Não reiniciar o inventário nem desfazer trabalho anterior.

## Ponto exato de retomada

1. Ler o [registro de reconciliação](reconciliacao_dossies.md), a [matriz de impacto](matriz_impacto_dossies.csv) e o [plano único atualizado](tarefas_operacionais.csv).
2. Retomar **T01/R06/R18**: obter os documentos oficiais citados no D2 (PDR ES 2024 e documentação territorial SESA 003/2026), conferir municípios/versão e referência temporal, confirmar Noroeste 1 como focal dentro de Norte e congelar a tabela central por hash. Selecionar a fonte populacional harmonizada e obter separadamente o padrão Brasil 2010. Não inferir municípios, pesos, versões ou vigências.
3. Em paralelo, **R08/R17**: verificar cobertura e layout por família, incluindo condições dos fluxos interestaduais, e inspecionar um pacote histórico SIGTAP antes de planejar aquisição ampla. Reutilizar infraestrutura comum; Python é preferencial em engenharia quando validado, com R/paridade preservados.
4. Aplicar o perfil do TCC apenas ao módulo cardiovascular. 2014–2024, G0–G5, classificação retrospectiva, quatro regiões e padronização estão decididos; não pedir nova confirmação dessas escolhas. IAM, whitelists históricas, população, composição focal, qualidade/publicação e ética permanecem pendentes no escopo identificado. IAM não bloqueia cálculos G0–G5 cujos próprios requisitos estejam satisfeitos.
5. Antes de calcular, preencher os pins vazios em `config/estudos/tcc_cardiovascular.csv` com fontes verificadas. `metadata/territorio/correspondencia_municipio_regiao_v2.csv` é somente cabeçalho. Os 77 candidatos/itens do Apêndice A não habilitam seleção final.

## O que pode ser reutilizado

- Cache gzip verificado e fonte histórica; chaves operacionais/públicas separadas; schema e fixtures corrigidos.
- Preparadores com interrupção antes de descarte de duplicatas/chaves ausentes; não foi implementada deduplicação física presumida.
- Reprocessamento isolado `reconciliacao_dossies_20261022`: 115 verificações aprovadas; CSV de estabelecimentos/habilitações idênticos aos da rodada 2 por SHA-256. Totais 12.548/1.963; 501 selecionados = 304 status interno validado + 197 revisar.
- Inventário territorial/fila/fichas da rodada 3 continuam diagnósticos válidos; não equivalem a regionalização ou normas validadas.
- Novo aplicador central com papel explícito, versão/hash e distinção entre data de evento e classificação congelada. Validação com dados sintéticos não comprova tabela oficial.
- Configuração institucional e perfil cardiovascular separados; grupos, famílias e exclusões transcritos; [21 pendências](pendencias_dossies.csv) vinculadas às tarefas.
- 16 scripts de teste R passando localmente (R 4.5.0). CI remoto R 4.3 não executado. Python 3.12.14/PySUS 2.0.4/PyArrow 19.0.1 observados, sem atualização de versão.

## Bloqueios precisos

A rede continua sem `saude.es.gov.br`, `cnes.datasus.gov.br`, `bvsms.saude.gov.br` e `servicodados.ibge.gov.br`. As recusas estão documentadas na rodada 3; o estado do ambiente nesta reconciliação segue restrito e sem hosts personalizados. Não foi alterada a política nem repetida tentativa sem mudança de estado. Revalidar acesso após atualização legítima da configuração.

Os anexos agora fornecem decisões metodológicas e referências de busca, mas não tabelas territoriais/populacionais oficiais, pacotes históricos SIGTAP/CNES ou microdados 2014–2024. Não há resultados substantivos do TCC a apresentar ou recalcular. A [lista de recálculo](produtos_recalculo_dossies.csv) distingue reprocessamento verificado e primeiro cálculo pendente.

A versão anterior deste ponto de continuidade está preservada em `referencias/estado_pre_reconciliacao.zip`. Os logs e manifestos das rodadas anteriores não foram reescritos. Proposta PDF, dossiês originais e relatório encerrado continuam preservados; nenhuma revisão humana ou participação discente foi presumida.
