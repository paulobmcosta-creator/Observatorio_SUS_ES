# Matriz preliminar e protocolo de validação

Versão de trabalho de 22/10/2026. Base: proposta pp. 12–16, especialmente a definição da validação documental, operacional e analítica nas pp. 13–14. Não há homologação nesta rodada.

## Seleção proposta e organização dos arquivos

A [matriz](matriz_indicadores_preliminar.csv) funciona como ficha por candidato: fonte/versão, campos, disponibilidade, numerador/denominador, fórmula, unidade, filtros, contagem, território, período, agregação, validação e pendências. O CSV é UTF-8, separado por vírgulas, com campos citados quando contêm vírgulas. `Não aplicável`, `não localizado` e `não avaliado` são informações distintas; não devem ser substituídas por zero.

| Grupo | Itens | Decisão preliminar |
|---|---|---|
| T01–T06 | Seis medidas existentes do piloto R | Manter como diagnóstico de processamento e descrição cadastral; não contar como matriz substantiva regional validada |
| S01 | Estabelecimentos com habilitação selecionada por linha de cuidado | Candidato prioritário de oferta; em revisão metodológica e bloqueado pelo contrato |
| S02 | Registros de habilitação selecionados | Medida complementar para reconciliar unidades; avaliar se ficará na matriz final ou apenas como apoio a S01 |
| S03 | Internações SUS de residentes por território | Candidato de utilização, após verificar layout, período e regra de contagem de AIH |
| S04 | Proporção de internações fora da região de residência | Candidato de fluxos; depende de S03 e correspondência territorial oficial |
| S05–S06 | Produção ambulatorial selecionada e óbitos por causas selecionadas | Candidatos condicionais; fora do núcleo inicial até justificar pertinência de SIA/SIM |

O número de linhas é uma escolha operacional desta proposta preliminar, **não uma meta quantitativa do projeto**. O núcleo limita-se a oferta cadastrada, utilização e fluxo; não adiciona automaticamente leitos, profissionais, ICSAP, ANS, índices compostos ou novas especialidades. S02 poderá ser absorvido como controle de S01, com justificativa registrada.

As seis medidas do piloto também não são as seis famílias analíticas futuras do roadmap. Elas podem excluir `NA` mas contar strings vazias; T02/T06 não impõem recorte mensal e podem reunir competências. Esses limites constam da matriz; não houve mudança no código histórico para fazê-lo coincidir com uma definição futura.

## Dimensões e evidências

A [avaliação preliminar](avaliacao_preliminar.csv) aplica qualitativamente as dimensões abaixo a cada uma das 12 linhas da matriz. As células descrevem evidência ou lacuna, sem pontuações. A leitura territorial e temporal foi separada para não ocultar que uma única competência não comprova comparabilidade temporal.

| Dimensão | Pergunta de avaliação | Evidência exigida |
|---|---|---|
| Relevância sanitária | O fenômeno é pertinente à atenção especializada? | Justificativa vinculada ao problema e ao recorte selecionado |
| Aderência aos objetivos | A medida responde a um dos seis objetivos? | Objetivo e pergunta de planejamento explícitos |
| Clareza operacional | Outra pessoa consegue aplicar a mesma regra? | Fórmula, filtros, campos, unidade e tratamento de ausentes |
| Estabilidade conceitual | Definição e classificação persistem no tempo? | Layouts/normas versionados e tabela de mudanças |
| Disponibilidade | Fonte pública acessível contém os campos necessários? | Fonte oficial, versão, extração e amostra inspecionada |
| Completude | Quais campos/territórios/períodos faltam? | Contagens absolutas, denominadores e padrão de ausência |
| Consistência | Chaves, vínculos e totais são coerentes? | Testes negativos, reconciliação e registro de divergências |
| Comparabilidade territorial | Os territórios e papéis das variáveis são equivalentes? | Correspondência oficial versionada, vigência e cardinalidade |
| Comparabilidade temporal | Os períodos representam o mesmo fenômeno? | Competências disponíveis, defasagem e situação preliminar/final |
| Periodicidade | É possível atualizar mantendo a definição? | Frequência da fonte, procedimento e registro de atualização |
| Sensibilidade às desigualdades | A medida permite leitura territorial pertinente? | Distribuições, cobertura e análise de artefatos de registro |
| Inteligibilidade | Título, unidade e limites são compreendidos? | Revisão documentada dos rótulos e teste de leitura supervisionado |
| Utilidade potencial para gestão | Que decisão/discussão pode subsidiar? | Pergunta concreta e registro de apreciação quando houver; não presumir adoção |

Não há pesos, notas de corte nem percentuais de qualidade aprovados. Uma futura proposta de escala deverá ser explicitamente proposta, fundamentada e deliberada antes de usada como critério de exclusão. Os requisitos de chave e estrutura de CSV são verificações técnicas, não limiares de qualidade assistencial.

## Três eixos de validação

1. **Documental — P1 com curadoria P3 supervisionada:** conferir definição, literatura, fonte oficial, manual, classificação, norma e vigência; registrar URL, versão e data de consulta. As referências da proposta (por exemplo OPAS 2018, WHO 2010 e Guerra et al. 2023) orientam a revisão, mas não foram consultadas externamente nesta rodada. S04 não é declarado reprodução do índice publicado de dependência regional. A aprovação documental requer justificativa e decisão registrada do responsável metodológico.
2. **Operacional — P2:** congelar insumos, preservar tipos textuais, verificar schemas, chaves e cardinalidades, executar casos válidos e inválidos e conciliar totais. Registrar código, ambiente, comando, resultado e SHA-256 de insumos/produtos. Script que retorna zero sem avaliar campos não é comprovação suficiente. Neste incremento a saída 1 sobre o snapshot é a detecção correta de incompatibilidade; não é aprovação do dado.
3. **Analítica — P1/coordenação:** verificar se a medida expressa o fenômeno definido, se permite comparação territorial/temporal e se variações podem ser artefatos de fonte. Analisar ausências, regras de contagem, denominadores, vigência, pequenos números e limites de interpretação. Registrar revisão e decisão; os testes automatizados não substituem essa etapa.

O formulário de decisão de cada candidato deve conter: ID/versão; evidências por dimensão; parecer documental/operacional/analítico; limitações; escopo aceito; pendências; responsável efetivo; data e referência da decisão. Enquanto não houver pessoas designadas, registrar **responsável funcional a designar**, sem atribuir participação a alunos do ciclo anterior.

## Estados e transições

- `candidato`: pertinência sugerida; definição e dados ainda incompletos.
- `especificado`: regra operacional completa, com pendências de dados explícitas.
- `calculável com evidência`: insumos e campos conferidos; regra aplicável, sem pressupor validade analítica.
- `testado`: comportamento verificado em escopo declarado (fixtures ou dados), com resultados e limitações.
- `em revisão metodológica`: divergência ou decisão substantiva pendente; não publicar como validado.
- `validado no escopo documentado`: três eixos apreciados e decisão identificável, com território/período/fonte explícitos.
- `excluído com justificativa`: critério e alternativa registrados; ausência de dados pode motivar adiamento, sem irrelevância sanitária presumida.

Os estados não são automaticamente uma escala crescente: uma mudança de layout, norma, território ou período reabre a revisão. O status interno `validado` da classificação de habilitações não promove S01/S02 para `validado no escopo documentado`. Não usar `homologado` sem decisão formal comprovada.

## Regras transversais de cálculo

CNES público, `CO_UNIDADE` e códigos municipais são textos e conceitos distintos. Não recompor identificadores por truncamento, concatenação ou preenchimento. Obter correspondência oficial município–região com fonte, vigência e regra temporal; exigir unicidade por período e registrar municípios não associados. Não chamar gestor de município de atendimento ou residência.

Estoques CNES mensais não se somam como produção anual. Fluxos SIH/SIA exigem regra de eventos/procedimentos e competência; internações, AIHs, pessoas e procedimentos não são equivalentes. Agregações de razões recalculam numerador e denominador, sem média simples de taxas municipais. Denominador zero produz valor não calculável/NA, nunca taxa zero; ausência de registro não vira zero observado. Registros sem território ficam explicitamente não classificados. Política de supressão de pequenos números deve ser deliberada antes da comunicação, sem limiar inventado nesta rodada.

Cadastro não comprova funcionamento, acesso, suficiência, qualidade ou vazio assistencial. Comparações são descritivas; não há inferência causal nem junções individuais entre sistemas sem chaves válidas. A análise prevista é pública e agregada, sem ampliação tácita para dados restritos ou coleta primária.
