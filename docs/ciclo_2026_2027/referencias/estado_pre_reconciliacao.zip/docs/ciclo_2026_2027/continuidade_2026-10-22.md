# Registro de continuidade — 22/10/2026

## Ponto exato de retomada

Retomar em **R04 de [tarefas_operacionais.csv](tarefas_operacionais.csv)**. Não repetir o inventário geral nem reabrir o relatório 2025–2026. O checkout-base e remoto conferidos são `6478f93a50d03270a78959730221f2ea5a643658`; a branch desta rodada é `feat/ciclo-2026-2027-transicao`.

1. Recuperar o objeto Git LFS de `tbEstabelecimento202601.csv` em área isolada e conferir SHA-256 `a6dd87e847e2905949dd160f1d88ddd5e7f088fdf61b1124404cf566297d36d6` e tamanho 284.224.999 bytes. Não sobrescrever os snapshots intermediários.
2. Inspecionar layout/chaves do objeto recuperado, relacionando `CO_UNIDADE` e `CO_CNES` como textos distintos. Não presumir que o campo `cnes` legado possa ser convertido em um deles.
3. Preparar correção pontual da serialização da linha 30 do schema de habilitações, sem alterar definição metodológica; alinhar a fixture de estabelecimentos às entradas realmente exigidas pelo código. Preservar evidências anteriores e testar a mudança.
4. A partir disso, propor uma nova saída versionada e comparar com a histórica. Antes de cálculo regional, concluir R06/R07: significado territorial, correspondência oficial com vigência e revisão normativa do recorte.

## O que está entregue

Inventário delimitado; diagnóstico com divergências; matriz preliminar T01–T06/S01–S06; avaliação qualitativa por dimensão; protocolo documental/operacional/analítico; tarefas e cronogramas dos três planos; verificador R, executor rastreável, testes e integração do teste ao CI. [Índice completo](README.md).

O teste novo passa em 14 cenários. A execução real reprova o contrato (61 passou, 7 falhou, 4 não executado; saída 1), corretamente. Os nove scripts já configurados no CI foram reexecutados nesta rodada; a consolidação dos comandos e da preservação está em [verificação final](verificacao_final_2026-10-22.md). O CI remoto em R 4.3 não foi executado; o ambiente local usa R 4.5.0.

Não há indicador substantivo validado nesta rodada. S01/S02 permanecem em revisão metodológica; S03/S04 são candidatos sem insumos SIH/layout oficial inspecionados; S05/S06 são condicionais, fora do núcleo inicial. Nenhuma base nova foi extraída, nenhuma classificação foi alterada e nenhuma rotina histórica foi substituída.

## Pendências sem bloqueio das entregas locais

- Drive/Docs: proxy recusou leitura. Para inventariar painel/RUE/relatórios individuais, será necessário acesso de leitura ao acervo ou cópias dos produtos. Isso não requer reabrir auditoria editorial do relatório encerrado.
- Autoria: participantes e bolsas 2026–2027 não foram designados; plano contém responsáveis funcionais. Cinco relatórios individuais e análises coletivas não foram atribuídos retroativamente.
- Metodologia: fontes normativas e regionalização oficial versionada; regra SIH de internação/AIH e janela comum; tratamento dos 197 registros selecionados em revisão; pequenos números e comunicação.
- Proveniência original: URL/data/hora/extrator dos snapshots não recuperados. As evidências desta rodada registram uma conferência nova, sem funcionar como prova retrospectiva.

## Limites permanentes desta rodada

PDF e relatório encerrado preservados. As cópias dos anexos têm hashes em `referencias/fontes_sha256.csv`. Nenhuma operação de escrita foi dirigida a Docs/Drive, parceiros ou estudantes. Não houve merge/publicação. As alterações locais estão preparadas para revisão técnica e metodológica; a revisão humana não é presumida concluída.
